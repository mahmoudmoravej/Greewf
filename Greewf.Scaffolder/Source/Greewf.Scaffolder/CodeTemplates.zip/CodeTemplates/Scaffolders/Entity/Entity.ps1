[T4Scaffolding.Scaffolder(Description = "complete scaffolder for entity")][CmdletBinding()]
param(        
	[Parameter(Mandatory=$true, ValueFromPipelineByPropertyName=$true)]$ModelType,
	[string]$DbContextType,
	[string]$CodeLanguage,
	[string]$RepositoryProject,
	[string]$RepositoryFolder='Repositories',
	[string]$RepositoryInterfaceFolder='Interfaces',
	[string]$WebProject,
	[string]$ModelFolder='Models',
	[string]$EntityProjectName,
	[string]$PermissionEntityFileName='Enums\Permissions.cs',
	[string]$PermissionEntityEnumName='PermissionEntity',
	[string]$PermissionNameSpaceName,
	[string]$PermissionCoordinatorFileName = 'PermissionCoordinator.cs',
	[string]$PermissionCoordinatorClassName = 'PermissionCoordinator',
	[string]$PermissionCoordinatorLoaderFunctionName='LoadPermissionRelationships',
	[string]$PermissionAttributeClass = 'PermissionsAttribute',
	[string]$ViewFolder = 'Views',	
	[string[]]$TemplateFolders,
	[switch]$Force = $false
)


[string]$path = (Get-Project).properties.item('LocalPath').value
$path=$path+"\CodeTemplates\Scaffolders"

. "$path\Entity\Utilities.ps1"

$TemplateFolders=$TemplateFolders+"$path\T4Scaffolding.EFRepository" 
$TemplateFolders=$TemplateFolders+"$path\MvcScaffolding.Controller" 
$TemplateFolders=$TemplateFolders+"$path\MvcScaffolding.RazorView" 

#1st: controller & views
Scaffold Controller  $ModelType -DbContextType $DbContextType -Repository -Force:$Force -NoChildItems -Project $WebProject

$foundModelType = Get-ProjectType $ModelType -Project $WebProject -BlockUi
$modelTypePluralized = Get-PluralizedWord $foundModelType.Name

Write-Host "Scaffolding Views..." -ForegroundColor blue
Scaffold Views -ViewScaffolder 'View' -Controller $modelTypePluralized -ModelType $foundModelType.FullName -Area $Area -Layout $Layout -SectionNames $SectionNames -PrimarySectionName $PrimarySectionName -ReferenceScriptLibraries:$ReferenceScriptLibraries -Project $WebProject -CodeLanguage $CodeLanguage -Force:$Force


#2nd:Repository

Write-Host "Scaffolding Repository Interface..." -ForegroundColor blue
ApplyTemplate -TemplateFileName "IRepository" -Project:$RepositoryProject -OutputPath:$RepositoryInterfaceFolder -OutputFilePostName:'Repository' -OutputFilePreName:'I' -RepositoryProject:$RepositoryProject -SubRepositoryNameSpace:'Repositories' -WebProject:$WebProject -SubViewModelNameSpace:'Models' -SubViewModelMetaDataNameSpace:'Models.MetaData'

Write-Host "Scaffolding Repository Class..." -ForegroundColor blue
ApplyTemplate -TemplateFileName "Repository" -Project:$RepositoryProject -OutputPath:$RepositoryFolder -OutputFilePostName:'Repository' -OutputFilePreName:'' -RepositoryProject:$RepositoryProject -SubRepositoryNameSpace:'Repositories' -WebProject:$WebProject -SubViewModelNameSpace:'Models' -SubViewModelMetaDataNameSpace:'Models.MetaData'

#3rd:ViewModels
$GridFolder = $ModelFolder+'\Grid'
$MetaDataFolder = $ModelFolder+'\EntitiesMetadata'
$ViewModelFolder = $ModelFolder+'\EntitiesViewModel'
$SearchCriteria = $ModelFolder+'\SearchCriteria'

Write-Host "Scaffolding ViewModel Classes..." -ForegroundColor blue
ApplyTemplate -TemplateFileName "ViewModel" -Project:$WebProject -OutputPath:$ViewModelFolder -OutputFilePostName:'ViewModel' -OutputFilePreName:'' -RepositoryProject:$RepositoryProject -SubRepositoryNameSpace:'Repositories' -WebProject:$WebProject -SubViewModelNameSpace:'Models' -SubViewModelMetaDataNameSpace:'Models.MetaData'
ApplyTemplate -TemplateFileName "ViewModelMetaData" -Project:$WebProject -OutputPath:$MetaDataFolder -OutputFilePostName:'MetaData' -OutputFilePreName:'' -RepositoryProject:$RepositoryProject -SubRepositoryNameSpace:'Repositories' -WebProject:$WebProject -SubViewModelNameSpace:'Models' -SubViewModelMetaDataNameSpace:'Models.MetaData'
ApplyTemplate -TemplateFileName "GridViewModel" -Project:$WebProject -OutputPath:$GridFolder -OutputFilePostName:'GridViewModel' -OutputFilePreName:'' -RepositoryProject:$RepositoryProject -SubRepositoryNameSpace:'Repositories' -WebProject:$WebProject -SubViewModelNameSpace:'Models' -SubViewModelMetaDataNameSpace:'Models.MetaData'
ApplyTemplate -TemplateFileName "SearchCriteria" -Project:$WebProject -OutputPath:$SearchCriteria -OutputFilePostName:'SearchCriteria' -OutputFilePreName:'' -RepositoryProject:$RepositoryProject -SubRepositoryNameSpace:'Repositories' -WebProject:$WebProject -SubViewModelNameSpace:'Models' -SubViewModelMetaDataNameSpace:'Models.MetaData'

#4th:Permissions
Write-Host "Scaffolding Permissions..." -ForegroundColor blue
$permissionEnumName = $foundModelType.Name+'Permission'

#4-1:adding main enum item(enum{...} modification by adding item)
$e=Get-EnumItem -fileName: $PermissionEntityFileName -projectName:$entityProjectName -enumName:$PermissionEntityEnumName
if($e)
{
	try
	{
		$e.addmember($modelTypePluralized,$null,-1)
		Write-Host "'$modelTypePluralized' enum item added to '$permissionEnumName' enum..." 
	}
	catch [Exception]
	{
		if ( $_.Exception.ToString().Contains('already exists'))
		{
			Write-Host "'$modelTypePluralized' enum item already exists in '$permissionEnumName' enum! Passed...(-Force not works on this currently)" -ForegroundColor:Magenta
		}
		else
		{
			throw
		}
	}	
}
else
{
	Write-Host "$PermissionEntityEnumName not found in file $PermissionEntityFileName of project:$entityProjectName!!..." -ForegroundColor:Red
}

#4-2:adding the enum (adding new enum{...} to a namespace) 
$e=Get-CodeItem -fileName: $PermissionEntityFileName -projectName:$entityProjectName -typeName:$PermissionNameSpaceName -typeCode:5	#5=vsCMElementNamespace
if($e)
{
	$oldEnum=Find-CodeItem -obj:$e -typeCode:10 -typeName:$permissionEnumName
	if(-not($oldEnum))
	{
		$o = ApplyTemplate -TemplateFileName "Permission" -Project:$WebProject  -IsOutputText -RepositoryProject:$RepositoryProject -SubRepositoryNameSpace:'Repositories' -WebProject:$WebProject -SubViewModelNameSpace:'Models' -SubViewModelMetaDataNameSpace:'Models.MetaData'
		$e.GetEndPoint(16).CreateEditPoint().Insert($o) #16 = EnvDTE.vsCMPart.vsCMPartBody
		Write-Host "'$permissionEnumName' enum added..." 
	}
	else
	{
		Write-Host "$permissionEnumName enum already defined! Passed...(-Force not works on this currently)" -ForegroundColor:Magenta
	}	
}
else
{
	Write-Host "$PermissionNameSpaceName not found in file $PermissionEntityFileName of project:$entityProjectName!!..." -ForegroundColor:Red
}

#4-3:adding the permission limitters (function modification)
$e=Get-CodeItem -fileName: $PermissionCoordinatorFileName -projectName:$RepositoryProject -typeName:$PermissionCoordinatorClassName -typeCode:1 #vsCMElement.vsCMElementClass = 1
if($e)
{
	$constructor = Find-CodeItem -obj:$e -typeCode:2 -typeName: $PermissionCoordinatorLoaderFunctionName #vsCMElementFunction = 2 (function)
	$blockEndPoint = $constructor.GetEndPoint(16).CreateEditPoint()
	$o = ApplyTemplate -TemplateFileName "PermissionLimitters" -Project:$RepositoryProject  -IsOutputText -RepositoryProject:$RepositoryProject -SubRepositoryNameSpace:'Repositories' -WebProject:$WebProject -SubViewModelNameSpace:'Models' -SubViewModelMetaDataNameSpace:'Models.MetaData'
	
	if(-not($blockEndPoint.GetText($constructor.GetStartPoint(16)).Contains($permissionEnumName))) #16 = EnvDTE.vsCMPart.vsCMPartBody
	{
		$blockEndPoint.Insert($o)
		Write-Host "'$permissionEnumName' permission limitters added..." 
	}
	else
	{
		Write-Host "$PermissionCoordinatorClassName already has some refrences of '$permissionEnumName'! Passed...(-Force not works on this currently)" -ForegroundColor:Magenta
		Write-Host "you can add it manually :" -ForegroundColor:Magenta
		Write-Host "$o" -ForegroundColor:Magenta		
	}	
}
else
{
	Write-Host "$PermissionCoordinatorClassName not found in file $PermissionCoordinatorFileName of project:$RepositoryProject!!..." -ForegroundColor:Red
}

#4-4:adding the PermissionConstructor to PermissionAttribute
$e = Get-ProjectType $PermissionAttributeClass -Project $WebProject
if($e)
{
	#$constructor = Find-CodeItem -obj:$e -typeCode:2 -typeName:$PermissionCoordinatorClassName #vsCMElementFunction = 2 (constructor)
	$blocStartPoint = $e.GetStartPoint(16).CreateEditPoint()#16 = EnvDTE.vsCMPart.vsCMPartBody
	$blocEndPoint = $e.GetEndPoint(16).CreateEditPoint()	#16 = EnvDTE.vsCMPart.vsCMPartBody
	$o = ApplyTemplate -TemplateFileName "PermissionAttribute" -Project:$RepositoryProject  -IsOutputText -RepositoryProject:$RepositoryProject -SubRepositoryNameSpace:'Repositories' -WebProject:$WebProject -SubViewModelNameSpace:'Models' -SubViewModelMetaDataNameSpace:'Models.MetaData'
	
	if(-not($blocEndPoint.GetText($blocStartPoint).Contains($o.Trim()))) 
	{
		$blocStartPoint.Insert($o)
		Write-Host "New constructor for '$permissionEnumName' added to $PermissionAttributeClass class..." 
	}
	else
	{
		Write-Host "$PermissionAttributeClass already has constructor for '$permissionEnumName'! Passed...(-Force not works on this currently)" -ForegroundColor:Magenta
		Write-Host "you can add it manually :" -ForegroundColor:Magenta
		Write-Host "$o" -ForegroundColor:Magenta
	}	
}
else
{
	Write-Host "$PermissionAttributeClass not found!!..." -ForegroundColor:Red
}


#4-5:adding the PermissionConstructor to commons ??



#scaffold entity 'Aien.CRM.Biz.Entities.TerritoryUser' -DbContextType 'Aien.CRM.Dal.CrmContext' -RepositoryProject '31-CRM.Biz' -WebProject:'50-CRM.UI.Web' -EntityProjectName:'30-CRM.Biz.Entities' -Force